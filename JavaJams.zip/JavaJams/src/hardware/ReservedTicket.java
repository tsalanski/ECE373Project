package hardware;

public class ReservedTicket {

}
