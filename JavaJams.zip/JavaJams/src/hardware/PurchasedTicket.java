package hardware;

public class PurchasedTicket {

}
